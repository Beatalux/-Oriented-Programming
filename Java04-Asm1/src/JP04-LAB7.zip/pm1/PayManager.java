package pm1;

public interface PayManager {
	long calculatePay(Employee emp);
	

}
