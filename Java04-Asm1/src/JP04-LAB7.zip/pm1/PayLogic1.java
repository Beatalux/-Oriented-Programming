package pm1;

public class PayLogic1 implements PayManager {
	public long calculatePay(Employ emp) {
		long pay=emp.getWorkHours()*1000+emp.getOverTimeHours()*15000;
		return pay;
	}

}
